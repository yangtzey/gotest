package routers

import (
	"testServer/controllers"
	"github.com/astaxie/beego"
)

func init() {
	beego.SetStaticPath("/down1", "download1")  
    beego.Router("/", &controllers.MainController{})
    beego.Router("/hello-world/:id([0-9]+)", &controllers.MainController{}, "get:HelloSitepoint")
    //beego.Router("/hello-world/:id([0-9]+)", &controllhers.MainController{}, "get:HelloSitepoint")
    beego.Router("/kq-world", &controllers.MainController{}, "post:Kqneu")
    beego.Router("/login", &controllers.MainController{}, "get:Login")
    beego.Router("/form_action", &controllers.MainController{}, "post:FormAction")
    beego.Router("/alipay", &controllers.MainController{}, "get:AlipayTest")
}
